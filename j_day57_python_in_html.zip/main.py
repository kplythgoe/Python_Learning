from flask import Flask, render_template
import requests

app = Flask(__name__)


@app.route('/')
def home():
    response = requests.get("https://api.npoint.io/1df6ace74c8fa0a26ae9")
    blog_data = response.json()
    return render_template("index.html", posts=blog_data)


@app.route('/post/<id>')
def post(id):
    id = int(id)
    response = requests.get("https://api.npoint.io/1df6ace74c8fa0a26ae9")
    blog_data = response.json()
    return render_template("post.html", posts=blog_data, post_id=id)


if __name__ == "__main__":
    app.run(debug=True)
