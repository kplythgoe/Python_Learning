import turtle
import pandas

FONT = ('monaco', 8, "")

screen = turtle.Screen()
screen.title("U.S States Game")
image = "blank_states_img.gif"
screen.addshape(image)
turtle.shape(image)
correct_states = []
playing = True

data = pandas.read_csv("50_states.csv")
states = data["state"].to_list()

while len(correct_states) < 50:
    user_guess = screen.textinput(title=f"{len(correct_states)}/50 States Correct", prompt="Name a state (type exit if "
                                                                                           "you give up)").title()
    if user_guess == "Exit":
        break
    if user_guess in states:
        correct_states.append(user_guess)
        print(f"{user_guess} is a state")
        state_info = data[data.state == user_guess]
        state_turtle = turtle.Turtle()
        state_turtle.penup()
        state_turtle.hideturtle()
        x_cord = int(state_info.x.iloc[0])
        y_cord = int(state_info.y.iloc[0])
        state_turtle.goto(x_cord, y_cord)
        state_turtle.write(user_guess, font=FONT)
        if len(correct_states) == 50:
            state_turtle.goto(-325, 0)
            winning_turtle = turtle.Turtle()
            winning_turtle.penup()
            winning_turtle.hideturtle()
            state_turtle.write("Congratulations. You have guess all of the states!", font=("monaco", 16, "bold"))
            playing = False
    else:
        print(f"{user_guess} is not a state")

# states to learn.csv
missing_states = []
for state in states:
    if state not in correct_states:
        missing_states.append(state)

missing = pandas.DataFrame(missing_states)
missing.to_csv("missing_states.csv")

