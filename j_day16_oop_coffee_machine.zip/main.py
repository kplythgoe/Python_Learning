from menu import Menu, MenuItem
from coffee_maker import CoffeeMaker
from money_machine import MoneyMachine


def make_drink(drink):
    if resources.is_resource_sufficient(drink):
        if money.make_payment(drink.cost):
            resources.make_coffee(drink)


menu = Menu()
resources = CoffeeMaker()
money = MoneyMachine()
running = True

while running:
    choice = input(f"What would you like? ({Menu.get_items(menu)}): ")
    if choice == "off":
        running = False
    else:
        if choice == "report":
            resources.report()
            money.report()
        else:
            make_drink(menu.find_drink(choice))