import time
from turtle import Screen
from player import Player
from car_manager import CarManager
from scoreboard import Scoreboard

screen = Screen()
screen.setup(width=600, height=600)
screen.tracer(0)

timmy = Player()
scoreboard = Scoreboard()
car_manager = CarManager()
speed = 0.1

screen.listen()
screen.onkeypress(timmy.go_forward, "Up")

game_is_on = True
while game_is_on:
    time.sleep(speed)
    screen.update()
    car_manager.create_car()
    car_manager.go_forward()

    for car in car_manager.all_cars:
        if timmy.distance(car) < 20 and (-10 <= car.ycor() - timmy.ycor() <= 20):
            scoreboard.game_over()
            game_is_on = False

    if timmy.ycor() > 300:
        scoreboard.level_up()
        scoreboard.update_scoreboard()
        timmy.reset()
        speed *= 0.7

screen.exitonclick()
