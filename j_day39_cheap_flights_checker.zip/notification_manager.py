import smtplib
import os

my_email = "kieranplythgoe@gmail.com"
password = os.environ["password"]

class NotificationManager:
    def send_email(self, flights_dict):
        with smtplib.SMTP("smtp.gmail.com") as connection:
            connection.starttls()
            connection.login(user=my_email, password=password)
            connection.sendmail(from_addr=my_email, to_addrs="kieranplythgoedev@outlook.com",
                                msg=f"Subject:Holiday Deal Alert\n\n")