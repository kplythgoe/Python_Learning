import smtplib
import os

my_email = "kieranplythgoe@gmail.com"
password = os.environ["password"]

class NotificationManager:
    def send_email(self, flights_dict):
        for record in flights_dict:
            subject = f"Great deal on flight to {record["arriving_to"][0]}!"
            message = (f"Only {record["price"]} pounds to fly from {record["departed_from"][0]} to "
                       f"{record["arriving_to"][0]} from {record["departure_time"]} to {record["arrival_time"]}")
            with smtplib.SMTP("smtp.gmail.com") as connection:
                connection.starttls()
                connection.login(user=my_email, password=password)
                connection.sendmail(from_addr=my_email, to_addrs="kieranplythgoedev@outlook.com",
                                    msg=f"Subject:{subject}\n\n{message}")
