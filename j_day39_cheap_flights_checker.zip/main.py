#This file will need to use the DataManager,FlightSearch, FlightData, NotificationManager classes to achieve the program requirements.
from data_manager import DataManager
from datetime import datetime
from flight_search import FlightSearch
from notification_manager import NotificationManager

sheet_data = DataManager()
sheet_data.get_data()
#print(sheet_data.prices_data)
flights = FlightSearch()

flight_prices = []

cheapest_flights = {
    "Paris": 10000000
}

for record in sheet_data.prices_data:
    flight_prices.append(flights.get_prices(record["iataCode"], record["lowestPrice"]))

#print(flight_prices)
#print(len(flight_prices["Paris"]))

cheapest_flight = 10000000

for city in flight_prices:
    for trip in city:
        if trip["arriving_to"][1] == "PAR" and trip["price"] < cheapest_flight:
            cheapest_flight = trip["price"]

print(cheapest_flight)

# print(cheapest_flights)
#message = NotificationManager()
#message.send_email(flight_prices)




