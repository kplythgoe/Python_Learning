from data_manager import DataManager
from flight_search import FlightSearch
from notification_manager import NotificationManager

sheet_data = DataManager()
sheet_data.get_data()
flights = FlightSearch()
flight_prices = []
cheapest_flights = {

}

for record in sheet_data.prices_data:
    flight_prices.append(flights.get_prices(record["iataCode"], record["lowestPrice"]))

notification = NotificationManager()
notification.send_email(flight_prices)





