import requests
import os

SHEETY_ENDPOINT = os.environ["SHEETY_ENDPOINT"]
BEARER_TOKEN = os.environ["BEARER_TOKEN"]

sheety_headers = {
    "Authorization": f"Bearer {BEARER_TOKEN}"
}

class DataManager:
    def __init__(self):
        self.prices_data = {}

    def get_data(self):
        response = requests.get(url=SHEETY_ENDPOINT, headers=sheety_headers)
        data = response.json()
        self.prices_data = data["prices"]
        return self.prices_data
