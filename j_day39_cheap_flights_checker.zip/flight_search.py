import requests
import os
from datetime import datetime
#print(response.json()["locations"][0]["code"])
KIWI_FLIGHT_API = os.environ["KIWI_FLIGHT_API"]

headers = {
    "apikey": KIWI_FLIGHT_API,
}

date_today = datetime.now().date()
date_in_six_months = datetime(date_today.year, date_today.month + 6, date_today.day)



class FlightSearch:
    def get_prices(self, city, max_price):
        flights = {
            "fly_from": "LON",
            "fly_to": city,
            "date_from": date_today,
            "date_to": date_in_six_months.date(),
            "curr": "GBP"
        }
        response = requests.get(url=f"https://api.tequila.kiwi.com/v2/search", params=flights, headers=headers)
        data = response.json()
        all_prices = []

        for trip in data["data"]:
            if trip["price"] < max_price:
                prices = {
                    "price": trip["price"],
                    "departed_from": [trip["cityFrom"], trip["cityCodeFrom"]],
                    "arriving_to": [trip["cityTo"], trip["cityCodeTo"]],
                    "departure_time": trip["local_departure"],
                    "arrival_time": trip["local_arrival"]
                }
                all_prices.append(prices)
        return all_prices

    def get_flight_data(self, city):
        flights = {
            "fly_from": "LON",
            "fly_to": city,
            "date_from": date_today,
            "date_to": date_in_six_months.date(),
            "curr": "GBP"
        }
        response = requests.get(url=f"https://api.tequila.kiwi.com/v2/search", params=flights, headers=headers)
        data = response.json()


    def get_destination_code(self, city):
        flight_details = {
            "term": city,
            "location_types": "city"
        }

        response = requests.get(url=f"https://api.tequila.kiwi.com/locations/query", params=flight_details,
                                headers=headers)
        data = response.json()
        return data["locations"][0]["code"]