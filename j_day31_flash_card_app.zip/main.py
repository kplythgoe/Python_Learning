from tkinter import *
import random
import pandas
BACKGROUND_COLOR = "#B1DDC6"

to_learn = {}
current_card = {}

try:
    data = pandas.read_csv("data/words_to_learn.csv")
except:
    original_data = pandas.read_csv("data/french_words.csv")
    to_learn = original_data.to_dict(orient="records")
else:
    to_learn = data.to_dict(orient="records")


# -------- FUNCTIONS ---------


def flip():
    canvas.itemconfig(canvas_image, image=card_back)
    canvas.itemconfig(word_text, text=current_card["English"], fill="white")
    canvas.itemconfig(title_text, text="English", fill="white")


def refresh():
    global current_card, flip_timer
    screen.after_cancel(flip_timer)
    current_card = (random.choice(to_learn))
    canvas.itemconfig(canvas_image, image=card_front)
    canvas.itemconfig(word_text, text=current_card["French"], fill="black")
    canvas.itemconfig(title_text, text="French", fill="black")
    flip_timer = screen.after(3000, flip)


def is_known():
    to_learn.remove(current_card)
    data = pandas.DataFrame(to_learn)
    data.to_csv("data/words_to_learn.csv", index=False)

    refresh()


# ------------ UI ------------

# Screen configuration
screen = Tk()
screen.title("Flashcard App")
screen.config(bg=BACKGROUND_COLOR, padx=50, pady=50)

flip_timer = screen.after(3000, flip)

# Canvas
canvas = Canvas(width=800, height=526, bg=BACKGROUND_COLOR, highlightthickness=0)
card_front = PhotoImage(file="images/card_front.png")
card_back = PhotoImage(file="images/card_back.png")
canvas_image = canvas.create_image(410, 263, image=card_front)
title_text = canvas.create_text(400, 150, text="Title", font=("arial", 40, "italic"))
word_text = canvas.create_text(400, 263, text="Word", font=("arial", 60, "bold"))
canvas.grid(row=0, column=0, columnspan=2)

# Buttons
incorrect_img = PhotoImage(file="images/wrong.png")
incorrect_button = Button(image=incorrect_img, highlightthickness=0, command=refresh)
incorrect_button.grid(row=1, column=0)

correct_img = PhotoImage(file="images/right.png")
correct_button = Button(image=correct_img, bg=BACKGROUND_COLOR, highlightthickness=0, command=is_known)
correct_button.grid(row=1, column=1)

refresh()

screen.mainloop()