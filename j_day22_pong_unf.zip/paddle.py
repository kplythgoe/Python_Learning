from turtle import Turtle


class Paddle(Turtle):
    def __init__(self, cords):
        self.paddles = []
        super().__init__()
        self.color("white")
        self.shape("square")
        self.penup()
        self.shapesize(stretch_wid=5, stretch_len=1)
        self.goto(cords)
        #self.paddles.append()

    def go_up(self):
        new_pos = self.ycor() + 30
        self.goto(self.xcor(), new_pos)

    def go_down(self):
        new_pos = self.ycor() - 30
        self.goto(self.xcor(), new_pos)


